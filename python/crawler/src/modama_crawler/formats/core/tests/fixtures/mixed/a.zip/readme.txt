a zip written by Python's zipfile
